import Groq from 'groq-sdk';

// ══════════════════════════════════════════════════════════════════════════════
//  🔑 PASTE YOUR GROQ API KEY BELOW  (get free key at https://console.groq.com)
// ══════════════════════════════════════════════════════════════════════════════
export const GROQ_API_KEY = "YOUR_GROQ_API_KEY_HERE";

// ✅ Current working vision model (as of 2025)
const VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct";

// ── Harmful Ingredient Database (WHO Child Nutrition Guidelines) ──────────────
const HARMFUL_MAP = {
  "hydrogenated":              { penalty: 4, reason: "Trans fats damage heart health in children" },
  "partially hydrogenated":    { penalty: 5, reason: "Trans fats strongly linked to childhood obesity" },
  "high fructose corn syrup":  { penalty: 4, reason: "Causes rapid blood sugar spikes in children" },
  "hfcs":                      { penalty: 4, reason: "High-fructose corn syrup — causes sugar spikes" },
  "sodium benzoate":           { penalty: 3, reason: "Linked to hyperactivity and ADHD in children" },
  "potassium bromate":         { penalty: 4, reason: "Potential carcinogen, banned in many countries" },
  "bha":                       { penalty: 3, reason: "BHA is a suspected carcinogen" },
  "bht":                       { penalty: 3, reason: "BHT may disrupt hormones in children" },
  "tbhq":                      { penalty: 3, reason: "TBHQ may cause nausea and vision disturbances" },
  "artificial colour":         { penalty: 2, reason: "Artificial colors linked to ADHD in kids" },
  "artificial color":          { penalty: 2, reason: "Artificial colors linked to ADHD in kids" },
  "artificial flavour":        { penalty: 2, reason: "Synthetic flavors — unknown long-term effects" },
  "artificial flavor":         { penalty: 2, reason: "Synthetic flavors — unknown long-term effects" },
  "msg":                       { penalty: 2, reason: "Excitotoxin, may affect young nervous systems" },
  "monosodium glutamate":      { penalty: 2, reason: "May cause headaches in sensitive children" },
  "red 40":                    { penalty: 3, reason: "Linked to behavioral issues in children" },
  "yellow 5":                  { penalty: 2, reason: "May trigger hyperactivity and allergies" },
  "yellow 6":                  { penalty: 2, reason: "Associated with hyperactivity" },
  "blue 1":                    { penalty: 2, reason: "Artificial dye, may cause allergic reactions" },
  "aspartame":                 { penalty: 3, reason: "Artificial sweetener, not recommended for children" },
  "acesulfame":                { penalty: 2, reason: "Artificial sweetener with long-term health concerns" },
  "sucralose":                 { penalty: 2, reason: "May disrupt gut microbiome in developing children" },
  "saccharin":                 { penalty: 3, reason: "Artificial sweetener, safety debated for kids" },
  "carrageenan":               { penalty: 2, reason: "May cause gut inflammation" },
  "sodium nitrate":            { penalty: 3, reason: "Linked to increased cancer risk" },
  "sodium nitrite":            { penalty: 3, reason: "Processed meat preservative, linked to cancer" },
  "propyl gallate":            { penalty: 2, reason: "Potential hormone disruptor" },
  "palm oil":                  { penalty: 1, reason: "High in saturated fat, problematic in excess" },
};

export function ruleBasedAnalysis(ingredientsText) {
  const lower = ingredientsText.toLowerCase();
  const triggered = [];
  let totalPenalty = 0;
  for (const [ingredient, data] of Object.entries(HARMFUL_MAP)) {
    if (lower.includes(ingredient)) {
      triggered.push({ ingredient, ...data });
      totalPenalty += data.penalty;
    }
  }
  return { triggered, totalPenalty: Math.min(totalPenalty, 30) };
}

export async function analyzeSnackImage(imageBase64, language) {
  const client = new Groq({ apiKey: GROQ_API_KEY, dangerouslyAllowBrowser: true });

  const isUrdu = language === 'urdu';
  const langInstruction = isUrdu
    ? 'Respond ONLY in Urdu language (Roman Urdu acceptable). Every text field must be in Urdu.'
    : 'Respond in clear English.';

  const systemPrompt = `You are NutriScan Kids — Pakistan's most trusted AI child nutrition analyst.
You evaluate packaged snacks for children aged 3-15 using WHO child nutrition guidelines.
${langInstruction}

CRITICAL: Your entire response must be ONLY a valid JSON object. No markdown, no backticks, no text outside JSON.

Required JSON structure (keep exact key names):
{
  "product_name": "detected product name or Unknown Snack",
  "brand": "brand name if visible, else Unknown",
  "category": "chips or biscuit or candy or juice or chocolate or other",
  "detected_ingredients": ["array", "of", "ingredients", "from", "label"],
  "nutrition_highlights": {
    "sugar_level": "Low or Medium or High or Very High",
    "sodium_level": "Low or Medium or High or Very High",
    "fat_level": "Low or Medium or High or Very High",
    "calories_per_serving": "number or estimated range as string",
    "artificial_additives": ["list of artificial additives found"]
  },
  "health_score": 5,
  "score_reasoning": "2-3 sentence explanation referencing WHO guidelines",
  "main_health_concerns": ["concern 1", "concern 2", "concern 3"],
  "positive_aspects": ["any positives, or empty array if none"],
  "healthy_alternatives": [
    {"name": "Alternative 1 available in Pakistan", "reason": "why it is healthier"},
    {"name": "Alternative 2 available in Pakistan", "reason": "why it is healthier"},
    {"name": "Alternative 3 available in Pakistan", "reason": "why it is healthier"}
  ],
  "parent_tip": "One actionable tip for Pakistani parents",
  "safe_frequency": "e.g. Once a week maximum or Avoid completely or Occasionally as a treat"
}

The health_score MUST be an integer 1 to 10. 1 = extremely unhealthy for children, 10 = very healthy.
Be strict — most ultra-processed Pakistani snacks score between 2 and 5.`;

  const response = await client.chat.completions.create({
    model: VISION_MODEL,
    messages: [
      { role: "system", content: systemPrompt },
      {
        role: "user",
        content: [
          {
            type: "image_url",
            image_url: { url: `data:image/jpeg;base64,${imageBase64}` }
          },
          {
            type: "text",
            text: "Analyze this packaged snack image. Carefully read all visible text including ingredients list, nutrition facts table, and product name. Return ONLY the JSON object with no extra text."
          }
        ]
      }
    ],
    max_tokens: 1500,
    temperature: 0.2,
  });

  const raw = response.choices[0].message.content.trim();

  // Extract JSON safely — handles cases where model wraps in markdown
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error("Could not parse AI response. Please try a clearer image of the ingredient label.");
  }

  const data = JSON.parse(jsonMatch[0]);

  // ── Hybrid Scoring: AI score + rule-based penalty ────────────────────────
  const ingredientStr = (data.detected_ingredients || []).join(' ');
  const { triggered, totalPenalty } = ruleBasedAnalysis(ingredientStr);
  const aiScore = Math.max(1, Math.min(10, parseInt(data.health_score) || 5));
  const penaltyPoints = Math.floor(totalPenalty / 8);
  const finalScore = Math.max(1, Math.min(10, aiScore - penaltyPoints));

  return {
    ...data,
    health_score: finalScore,
    ai_raw_score: aiScore,
    rule_based_flags: triggered,
  };
}

export function getScoreMetadata(score) {
  if (score >= 8) return {
    label: 'Healthy Choice',
    labelUrdu: 'صحت مند انتخاب',
    color: '#10b981',
    bg: 'linear-gradient(135deg, #d1fae5, #a7f3d0)',
    emoji: '🟢',
    badge: 'SAFE',
  };
  if (score >= 6) return {
    label: 'Acceptable',
    labelUrdu: 'قابل قبول',
    color: '#84cc16',
    bg: 'linear-gradient(135deg, #ecfccb, #d9f99d)',
    emoji: '🟡',
    badge: 'MODERATE',
  };
  if (score >= 4) return {
    label: 'Consume with Caution',
    labelUrdu: 'احتیاط سے استعمال کریں',
    color: '#f59e0b',
    bg: 'linear-gradient(135deg, #fef3c7, #fde68a)',
    emoji: '🟠',
    badge: 'CAUTION',
  };
  return {
    label: 'Avoid for Children',
    labelUrdu: 'بچوں کے لیے نقصاندہ',
    color: '#ef4444',
    bg: 'linear-gradient(135deg, #fee2e2, #fecaca)',
    emoji: '🔴',
    badge: 'AVOID',
  };
}
