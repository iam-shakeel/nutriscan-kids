import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload, Scan, AlertTriangle, CheckCircle, Leaf,
  ChevronDown, ChevronUp, ShieldCheck, Zap, X,
  Apple, Star, AlertCircle, RefreshCw
} from 'lucide-react';
import { analyzeSnackImage, getScoreMetadata } from './utils/analyzeSnack';
import './App.css';

// ─────────────────────────────────────────────────────────────────────────────
// HEADER
// ─────────────────────────────────────────────────────────────────────────────
function Header() {
  return (
    <motion.header
      className="app-header"
      initial={{ opacity: 0, y: -28 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="header-glow" />
      <div className="header-content">
        <motion.div
          className="logo-wrap"
          animate={{ rotate: [0, -6, 6, -3, 3, 0] }}
          transition={{ duration: 2, delay: 2, repeat: Infinity, repeatDelay: 9 }}
        >
          🍎
        </motion.div>
        <div>
          <h1 className="app-title">NutriScan Kids</h1>
          <p className="app-subtitle">AI-Powered Child Snack Health Evaluator · Pakistan</p>
        </div>
      </div>
      <p className="header-tagline">
        Snap a photo of any snack package — get an instant child safety report powered by AI
      </p>
      <div className="header-badges">
        <span className="hbadge">🤖 Llama 4 Vision AI</span>
        <span className="hbadge">🛡️ WHO Guidelines</span>
        <span className="hbadge">🇵🇰 Pakistan Ready</span>
        <span className="hbadge">⚗️ 29 Ingredient Checks</span>
      </div>
    </motion.header>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// IMAGE UPLOADER
// ─────────────────────────────────────────────────────────────────────────────
function ImageUploader({ imagePreview, onImageChange, onClear }) {
  const inputRef = useRef();
  const [dragging, setDragging] = useState(false);

  const handleFile = useCallback((file) => {
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => onImageChange(file, e.target.result);
    reader.readAsDataURL(file);
  }, [onImageChange]);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  }, [handleFile]);

  return (
    <motion.div
      className="card"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
    >
      <div className="card-label">
        <Upload size={15} /> Upload Snack Package Photo
      </div>

      {imagePreview ? (
        <div className="preview-wrap">
          <img src={imagePreview} alt="Snack package" className="preview-img" />
          <button className="clear-btn" onClick={onClear}>
            <X size={14} /> Remove
          </button>
          <div className="preview-tip">✅ Image ready — click Analyze below</div>
        </div>
      ) : (
        <div
          className={`dropzone ${dragging ? 'dragging' : ''}`}
          onDragOver={e => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current.click()}
          role="button"
          tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && inputRef.current.click()}
        >
          <div className="dropzone-icon">📦</div>
          <p className="dropzone-title">Drop snack package image here</p>
          <p className="dropzone-sub">or <span className="dropzone-link">click to browse</span></p>
          <p className="dropzone-formats">JPG · PNG · WEBP · up to 4MB</p>
          <div className="dropzone-tips">
            <span>💡 Capture the <strong>ingredient list</strong> clearly</span>
            <span>☀️ Good lighting = better AI reading</span>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={e => handleFile(e.target.files[0])}
          />
        </div>
      )}
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// LANGUAGE SELECTOR
// ─────────────────────────────────────────────────────────────────────────────
function LanguageSelector({ language, setLanguage }) {
  return (
    <motion.div
      className="card lang-card"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.22 }}
    >
      <div className="card-label">🌐 Response Language / زبان</div>
      <div className="lang-buttons">
        <button
          className={`lang-btn ${language === 'english' ? 'active' : ''}`}
          onClick={() => setLanguage('english')}
        >
          🇬🇧 English
        </button>
        <button
          className={`lang-btn ${language === 'urdu' ? 'active' : ''}`}
          onClick={() => setLanguage('urdu')}
        >
          🇵🇰 اردو (Urdu)
        </button>
      </div>
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ANALYZE BUTTON
// ─────────────────────────────────────────────────────────────────────────────
function AnalyzeButton({ onClick, loading, disabled }) {
  return (
    <motion.button
      className={`analyze-btn ${loading ? 'loading' : ''}`}
      onClick={onClick}
      disabled={disabled || loading}
      whileHover={!disabled && !loading ? { scale: 1.02, y: -2 } : {}}
      whileTap={!disabled && !loading ? { scale: 0.97 } : {}}
    >
      {loading ? (
        <><div className="spinner" /> Analyzing with AI...</>
      ) : (
        <><Scan size={21} /> Analyze Snack Health</>
      )}
    </motion.button>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SCORE RING
// ─────────────────────────────────────────────────────────────────────────────
function ScoreRing({ score, meta }) {
  const r    = 52;
  const circ = 2 * Math.PI * r;
  const fill = (score / 10) * circ;

  return (
    <div className="score-ring-wrap">
      <svg width="136" height="136" viewBox="0 0 136 136">
        <circle cx="68" cy="68" r={r} fill="none" stroke="#e5e7eb" strokeWidth="10" />
        <motion.circle
          cx="68" cy="68" r={r} fill="none"
          stroke={meta.color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={circ - fill}
          transform="rotate(-90 68 68)"
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: circ - fill }}
          transition={{ duration: 1.5, ease: 'easeOut', delay: 0.3 }}
        />
      </svg>
      <div className="score-ring-inner">
        <motion.span
          className="score-number"
          style={{ color: meta.color }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, delay: 0.6 }}
        >
          {score}
        </motion.span>
        <span className="score-denom">/10</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// LEVEL BAR
// ─────────────────────────────────────────────────────────────────────────────
function LevelBar({ label, level }) {
  const map    = { Low: 1, Medium: 2, High: 3, 'Very High': 4 };
  const colors = { 1: '#10b981', 2: '#84cc16', 3: '#f59e0b', 4: '#ef4444' };
  const val    = map[level] || 2;

  return (
    <div className="level-bar-wrap">
      <span className="level-bar-label">{label}</span>
      <div className="level-bar-track">
        {[1,2,3,4].map(i => (
          <motion.div
            key={i}
            className="level-bar-seg"
            style={{ background: i <= val ? colors[val] : '#e5e7eb' }}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.1 + i * 0.07 }}
          />
        ))}
      </div>
      <span className="level-bar-val" style={{ color: colors[val] }}>{level || 'N/A'}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RESULT CARD
// ─────────────────────────────────────────────────────────────────────────────
function ResultCard({ result, language }) {
  const meta   = getScoreMetadata(result.health_score);
  const isUrdu = language === 'urdu';
  const [flagsOpen, setFlagsOpen] = useState(false);

  const fadeUp = (delay = 0) => ({
    initial:    { opacity: 0, y: 16 },
    animate:    { opacity: 1, y: 0 },
    transition: { delay, duration: 0.4 },
  });

  return (
    <motion.div className="results-wrap" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>

      {/* Score Hero */}
      <motion.div className="score-hero" style={{ background: meta.bg }} {...fadeUp(0.05)}>
        <ScoreRing score={result.health_score} meta={meta} />
        <div className="score-info">
          <span className="score-badge" style={{ background: meta.color }}>
            {meta.emoji} {meta.badge}
          </span>
          <h2 className="score-label" style={{ color: meta.color }}>
            {isUrdu ? meta.labelUrdu : meta.label}
          </h2>
          <h3 className="score-product">{result.product_name || 'Unknown Snack'}</h3>
          {result.brand && result.brand !== 'Unknown' && (
            <p className="score-brand">by {result.brand} · {result.category}</p>
          )}
          {result.safe_frequency && (
            <p className="score-frequency">🗓️ {result.safe_frequency}</p>
          )}
          {result.ai_raw_score && result.rule_based_flags?.length > 0 && (
            <p className="score-adjusted">
              AI: {result.ai_raw_score}/10 → Adjusted to {result.health_score}/10 after safety scan
            </p>
          )}
        </div>
      </motion.div>

      {/* Score Reasoning */}
      {result.score_reasoning && (
        <motion.div className="card reasoning-card" {...fadeUp(0.16)}>
          <div className="card-label"><Star size={14} /> Why This Score?</div>
          <p className="reasoning-text">{result.score_reasoning}</p>
        </motion.div>
      )}

      {/* Nutrition Levels */}
      <motion.div className="card" {...fadeUp(0.22)}>
        <div className="card-label"><Zap size={14} /> Nutrition Levels</div>
        <div className="nutrition-grid">
          <LevelBar label="🍬 Sugar"  level={result.nutrition_highlights?.sugar_level}  />
          <LevelBar label="🧂 Sodium" level={result.nutrition_highlights?.sodium_level} />
          <LevelBar label="🥑 Fat"    level={result.nutrition_highlights?.fat_level}    />
        </div>
        {result.nutrition_highlights?.calories_per_serving && (
          <p className="calories-note">
            ⚡ Approx. <strong>{result.nutrition_highlights.calories_per_serving} kcal</strong> per serving
          </p>
        )}
        {result.nutrition_highlights?.artificial_additives?.length > 0 && (
          <div className="additives-wrap">
            <p className="additives-label">⚗️ Artificial Additives Found:</p>
            <div className="tags-wrap">
              {result.nutrition_highlights.artificial_additives.map((a, i) => (
                <span key={i} className="tag tag-red">{a}</span>
              ))}
            </div>
          </div>
        )}
      </motion.div>

      {/* Health Concerns */}
      {result.main_health_concerns?.length > 0 && (
        <motion.div className="card concerns-card" {...fadeUp(0.28)}>
          <div className="card-label"><AlertTriangle size={14} /> Health Concerns for Children</div>
          <ul className="concerns-list">
            {result.main_health_concerns.map((c, i) => (
              <motion.li key={i} initial={{ opacity:0, x:-10 }} animate={{ opacity:1, x:0 }} transition={{ delay: 0.32 + i * 0.07 }}>
                <AlertCircle size={14} className="concern-icon" /><span>{c}</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      )}

      {/* Positive Aspects */}
      {result.positive_aspects?.length > 0 && (
        <motion.div className="card positive-card" {...fadeUp(0.33)}>
          <div className="card-label"><CheckCircle size={14} /> Positive Aspects</div>
          <ul className="positive-list">
            {result.positive_aspects.map((p, i) => (
              <li key={i}><span className="pos-icon">✅</span>{p}</li>
            ))}
          </ul>
        </motion.div>
      )}

      {/* Detected Ingredients */}
      {result.detected_ingredients?.length > 0 && (
        <motion.div className="card" {...fadeUp(0.37)}>
          <div className="card-label"><Leaf size={14} /> Detected Ingredients</div>
          <div className="tags-wrap">
            {result.detected_ingredients.map((ing, i) => {
              const bad = result.rule_based_flags?.some(f => ing.toLowerCase().includes(f.ingredient));
              return <span key={i} className={`tag ${bad ? 'tag-red' : 'tag-green'}`}>{ing}</span>;
            })}
          </div>
          {result.rule_based_flags?.length > 0 && (
            <p className="harmful-note">🔴 Red = harmful/flagged ingredients</p>
          )}
        </motion.div>
      )}

      {/* WHO Safety Flags */}
      {result.rule_based_flags?.length > 0 && (
        <motion.div className="card flags-card" {...fadeUp(0.41)}>
          <button className="flags-toggle" onClick={() => setFlagsOpen(!flagsOpen)}>
            <div className="flags-toggle-left">
              <ShieldCheck size={14} />
              <span>WHO Safety Flags — {result.rule_based_flags.length} harmful ingredient{result.rule_based_flags.length > 1 ? 's' : ''} detected</span>
            </div>
            {flagsOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          <AnimatePresence>
            {flagsOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.26 }}
                style={{ overflow: 'hidden' }}
              >
                <div className="flags-list">
                  {result.rule_based_flags.map((flag, i) => (
                    <div key={i} className="flag-item">
                      <span className="flag-ingredient">⚠️ {flag.ingredient}</span>
                      <span className="flag-reason">{flag.reason}</span>
                      <span className="flag-penalty">−{flag.penalty}pts</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Healthy Alternatives */}
      {result.healthy_alternatives?.length > 0 && (
        <motion.div className="card alternatives-card" {...fadeUp(0.46)}>
          <div className="card-label"><Apple size={14} /> Healthier Alternatives in Pakistan</div>
          <div className="alternatives-grid">
            {result.healthy_alternatives.map((alt, i) => (
              <motion.div
                key={i} className="alt-item"
                initial={{ opacity:0, scale:0.93 }}
                animate={{ opacity:1, scale:1 }}
                transition={{ delay: 0.5 + i * 0.09 }}
              >
                <div className="alt-emoji">🥗</div>
                <div>
                  <p className="alt-name">{alt.name}</p>
                  <p className="alt-reason">{alt.reason}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Parent Tip */}
      {result.parent_tip && (
        <motion.div className="card tip-card" {...fadeUp(0.54)}>
          <div className="tip-text">
            <span className="tip-icon">💡</span>
            <div><strong>Parent Tip:</strong> {result.parent_tip}</div>
          </div>
        </motion.div>
      )}

      <motion.p className="disclaimer" {...fadeUp(0.6)}>
        ⚠️ For informational purposes only. Always consult a certified pediatric nutritionist for dietary advice.
      </motion.p>
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// LOADING STEPS
// ─────────────────────────────────────────────────────────────────────────────
function LoadingSteps() {
  const steps = [
    { icon: '📸', text: 'Reading package image...' },
    { icon: '🔍', text: 'Extracting ingredients via AI OCR...' },
    { icon: '🧠', text: 'Scoring against WHO child nutrition guidelines...' },
    { icon: '🛡️', text: 'Running 29-point harmful ingredient safety check...' },
    { icon: '💚', text: 'Finding healthier Pakistani snack alternatives...' },
  ];
  return (
    <motion.div className="loading-steps" initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }}>
      <p className="loading-title">🤖 AI Analysis in Progress</p>
      {steps.map((s, i) => (
        <motion.div
          key={s.text} className="loading-step"
          initial={{ opacity:0, x:-12 }} animate={{ opacity:1, x:0 }}
          transition={{ delay: i * 0.7 }}
        >
          <span>{s.icon}</span><span>{s.text}</span>
        </motion.div>
      ))}
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PLACEHOLDER
// ─────────────────────────────────────────────────────────────────────────────
function Placeholder() {
  const features = [
    '🏆 Health Score 1–10', '⚠️ Risk Detection',    '💚 Safe Alternatives',
    '🇵🇰 Urdu Support',     '📋 WHO Guidelines',    '🛡️ 29 Safety Checks',
    '👨‍👩‍👧 Parent Tips',       '🔬 Ingredient OCR',   '⚗️ Additive Scan',
  ];
  return (
    <motion.div className="placeholder-card" initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}>
      <motion.div
        className="placeholder-icon"
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
      >🔬</motion.div>
      <h3>Your Analysis Results</h3>
      <p>
        Upload a clear photo of a snack package label, choose your language,
        then click <strong>"Analyze Snack Health"</strong> for an instant child safety report.
      </p>
      <div className="placeholder-features">
        {features.map(f => <div key={f} className="feat">{f}</div>)}
      </div>
      <p className="placeholder-bottom">Powered by <strong>Groq Llama 4 Scout Vision</strong> — free & fast ⚡</p>
    </motion.div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────
export default function App() {
  const [image, setImage]               = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [language, setLanguage]         = useState('english');
  const [loading, setLoading]           = useState(false);
  const [result, setResult]             = useState(null);
  const [error, setError]               = useState(null);

  const handleImageChange = (file, preview) => {
    setImage(file);
    setImagePreview(preview);
    setResult(null);
    setError(null);
  };

  const handleClear = () => {
    setImage(null);
    setImagePreview(null);
    setResult(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!image) { setError('Please upload a snack package image first.'); return; }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload  = e => resolve(e.target.result.split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(image);
      });

      const data = await analyzeSnackImage(base64, language);
      setResult(data);
      setTimeout(() => {
        document.querySelector('.results-wrap')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);

    } catch (err) {
      let msg = err.message || 'Analysis failed. Please try again.';
      if (msg.includes('401') || msg.toLowerCase().includes('auth'))
        msg = '❌ Invalid API key. Update GROQ_API_KEY in src/utils/analyzeSnack.js';
      else if (msg.includes('429'))
        msg = '⏳ Rate limit reached. Please wait a moment and try again.';
      else if (msg.includes('parse') || msg.includes('JSON'))
        msg = '🖼️ Could not read the label clearly. Try a sharper, well-lit photo.';
      else if (msg.includes('decommissioned') || msg.includes('model'))
        msg = '⚙️ Model error. Check the model name in src/utils/analyzeSnack.js';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <div className="container">
        <Header />

        <div className="main-grid">
          {/* ── Left: Input Panel ── */}
          <div className="input-panel">
            <ImageUploader
              imagePreview={imagePreview}
              onImageChange={handleImageChange}
              onClear={handleClear}
            />
            <LanguageSelector language={language} setLanguage={setLanguage} />

            <AnimatePresence>
              {error && (
                <motion.div
                  className="error-box"
                  initial={{ opacity:0, y:-10 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-10 }}
                >
                  <AlertTriangle size={17} /><span>{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            <AnalyzeButton onClick={handleAnalyze} loading={loading} disabled={!image} />

            {result && !loading && (
              <motion.button className="reset-btn" onClick={handleClear} initial={{ opacity:0 }} animate={{ opacity:1 }}>
                <RefreshCw size={15} /> Scan Another Snack
              </motion.button>
            )}

            {loading && <LoadingSteps />}
          </div>

          {/* ── Right: Results Panel ── */}
          <div className="results-panel">
            <AnimatePresence mode="wait">
              {result
                ? <ResultCard key="result" result={result} language={language} />
                : !loading && <Placeholder key="placeholder" />
              }
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
